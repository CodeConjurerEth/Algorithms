﻿class Challenge5
{
	/**
	 * Looking for additional challenges to earn hints for your main assignment ?
	 * Ask your teacher for a random challenge! 
	 */
}
