﻿using System;
using System.Collections.Generic;

class Challenge1_RandomDeck
{
	private static Random random = new Random();

	public static List<HearthStoneCard> Run()
	{
		List<HearthStoneCard> result = new List<HearthStoneCard>();
		
		Console.WriteLine("TODO: Challenge1_RandomDeck.Run -> TODO create a random deck here");

		return result;
	}
}

