﻿using System;
using System.Collections.Generic;

class Challenge4_SortYourRandomDeck
{
	public static List<HearthStoneCard> Run()
	{
		List<HearthStoneCard> deck = Challenge1_RandomDeck.Run();

		Console.WriteLine("TODO: Challenge4_SortYourRandomDeck.Run -> TODO complete this or one of the many other challenges to get a hint for your assignments");

		deck.Sort();
		return deck;
	}
}

