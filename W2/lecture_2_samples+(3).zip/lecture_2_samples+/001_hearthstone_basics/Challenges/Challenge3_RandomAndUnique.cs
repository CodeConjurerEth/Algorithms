﻿using System;
using System.Collections.Generic;

class Challenge3_RandomAndUnique
{
	private static Random random = new Random(10);

	public static List<HearthStoneCard> Run()
	{ 
		Console.WriteLine("TODO: Challenge3_RandomAndUnique.Run -> TODO complete this or one of the many other challenges to get a hint for your assignments");
		return null;
	}
}
