﻿using System;
using System.Collections.Generic;

class Challenge2_PredictablyRandomDeck
{
	private static Random random = new Random();

	public static List<HearthStoneCard> Run()
	{
		List<HearthStoneCard> result = new List<HearthStoneCard>();

		Console.WriteLine("TODO: Challenge2_PredictablyRandomDeck.Run -> TODO create a predictable random deck");

		return result;
	}
}
