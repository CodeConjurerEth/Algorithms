﻿enum MinionRace
{
	BEAST,
	DEMON,
	DRAGON,
	ELEMENTAL,
	MECH,
	MURLOC,
	PIRATE,
	TOTEM,
	NONE
}
