﻿class SpellCard : HearthStoneCard
{
	public SpellCard(HeroClass pHeroClass, int pManaCost, string pName, string pCardText) : 
		base(pHeroClass, pManaCost, pName, pCardText)
	{
	}
}
