﻿using System;
using System.Collections.Generic;
using System.Linq;

class MainClass
{
	//the format of the function pointer has to be specified like this, outside of any method
	delegate void Function();

	public static void Main(string[] args)
	{
		//now I can just declare a variable of that type of function
		Function myMethod = null;

		//assign a method
		myMethod = printSomething;

		//call it
		myMethod();

		Console.WriteLine("------------------------------------------");

		//I can also 'add' a function call
		myMethod += printSomethingElse;

		//now both of them will be called
		myMethod();

		Console.WriteLine("------------------------------------------");

		//this also works across class boundaries
		SampleClass sampleClass = new SampleClass();
		sampleClass.OnMouseClick += onMouseClickHandler;
		sampleClass.TriggerMouseClickEvent();

		Console.ReadLine();
	}

	private static void printSomething()
	{
		Console.WriteLine("IT LIIIVES");
	}

	private static void printSomethingElse()
	{
		Console.WriteLine("Something else");
	}

	private static void onMouseClickHandler()
	{
		Console.WriteLine("Handling mouse click!");
	}

}

class SampleClass
{
	public delegate void MouseEvent();
	public MouseEvent OnMouseClick = delegate {};

	public void TriggerMouseClickEvent()
	{
		OnMouseClick();
	}
}
