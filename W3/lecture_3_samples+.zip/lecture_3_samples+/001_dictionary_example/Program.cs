﻿using System;
using System.Collections.Generic;
using System.Linq;

class MainClass
{
	public static void Main(string[] args)
	{
		Dictionary<string, int> highScores = new Dictionary<string, int>();
		highScores["Wiebe"] = 1064500;
		highScores["Mitchell"] = 933900;
		highScores["Lakeman"] = 1247700;

		Console.WriteLine("By Key");
		foreach (KeyValuePair<string, int> highScore in highScores.OrderBy(key => key.Key)) {
			Console.WriteLine("Player {0} - Score {1}", highScore.Key, highScore.Value);
		}

		Console.WriteLine("By Value");
		foreach (KeyValuePair<string, int> highScore in highScores.OrderBy(key => key.Value)) {
			Console.WriteLine("Player {0} - Score {1}", highScore.Key, highScore.Value);
		}

		Console.ReadLine();
	}
}
